package com.amazon.loading;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
public class NotofySubscriber {
	

	public static void readConf(String path,long time)
	{
		BufferedReader br =null;
		File file = new File(path);
		for(File f :file.listFiles() )
		{
			try
			{
			if(f.getName().contains(".conf"))
			{
				System.out.println(f.getName());
				String line=null; 
				br = new BufferedReader(new FileReader(f));
				while((line=br.readLine())!=null)
				{
					String[] str = line.split(",");
					System.out.println(str[0]);
					String midquery =generateQuery(str[0]);
					midquery = "select count(*) cnt from all_csv_records where "+midquery + " and insert_at='"+time+"'";
					Connection con =LoadCSV.getConnection();
					Statement stmt = con.createStatement();
					ResultSet rs = stmt.executeQuery(midquery);
						if(rs.next())
						{
							int cnt = rs.getInt("cnt");
							System.out.println(cnt);
							if(cnt>0)
							{
								sendMail("your Configureation"+str[0]+" has been matched",str[1]);
							}
								
						}
						
					
				}
			}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}

	private static String generateQuery(String string) 
	{
		StringBuilder finalQuery =new StringBuilder();
		if(string.contains("AND"))
		{
			String[] andquery =string.split("AND");
			int andcnt=andquery.length;
			for(String and : andquery)
			{
				if(string.contains("OR"))
				{
					String[] orquery = and.split("OR");
					int orcnt=orquery.length;
					for(String or: orquery)
					{
						if(orcnt>1)
						{
							finalQuery.append(condStmt(or.trim())+"OR");
							orcnt--;
						}
					}
				}
				else
				{
					finalQuery.append(condStmt(and.trim()));
				}
				if(andcnt>1)
				{
					finalQuery.append(" AND ");
					andcnt--;
				}
				
			}
		}
		else
		{
			finalQuery.append(condStmt(string.trim()));
		}
		System.out.println(finalQuery.toString());
		return finalQuery.toString();
		
	}
	
	private static String condStmt(String str)
	{
		String[] opr ={"!=",">=","<=","=",">","<"};
		for(String op:opr)
		{
			if(str.contains(op))
				return "Attribute_name='"+str.split(op)[0].trim()+"' AND "+"Attribute_value"+op+"'"+str.split(op)[1].trim()+"'";
		}
		return null;
	}
	private static void sendMail(String msg, String recep)
	{
		// Recipient's email ID needs to be mentioned.
	      String to = recep;

	      // Sender's email ID needs to be mentioned
	      String from = "yourgmailid@gmail.com";

	  
	      
	      //Get the session object  
	      Properties props = new Properties();  
	      props.put("mail.smtp.host", "smtp.gmail.com");  
	      props.put("mail.smtp.socketFactory.port", "465");  
	      props.put("mail.smtp.socketFactory.class",  
	                "javax.net.ssl.SSLSocketFactory");  
	      props.put("mail.smtp.auth", "true");  
	      props.put("mail.smtp.port", "465");  
	       
	      Session session = Session.getDefaultInstance(props,  
	       new javax.mail.Authenticator() {  
	       protected PasswordAuthentication getPasswordAuthentication() {  
	       return new PasswordAuthentication("yourgmailid@gmail.com","xxxxxx@xxxxx");//change accordingly  
	       }  
	      });  
	       
	      //compose message  
	      try {  
	       MimeMessage message = new MimeMessage(session);  
	       message.setFrom(new InternetAddress("yourgmailid@gmail.com"));//change accordingly  
	       message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
	       message.setSubject("Amazing Subscriber Notification System");  
	       message.setText(msg);  
	         
	       //send message  
	       Transport.send(message);  
	      
	       System.out.println("message sent successfully");  
	       
	      } catch (MessagingException e) {throw new RuntimeException(e);}	}
}
