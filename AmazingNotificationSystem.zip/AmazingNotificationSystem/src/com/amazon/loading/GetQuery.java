package com.amazon.loading;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class GetQuery extends Thread{

	String itemId;
	GetQuery(String str)
	{
		itemId=str;
		start();
	}
	public void run()
	{	
		LoadCSV.callProc();
		fetch();
	}
	private void fetch()
	{
		String query = "select * from all_csv_records where item = '"+itemId+"'"; 
		try{
		Connection con =LoadCSV.getConnection();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		while(rs.next())
		{
			String attribute_name = rs.getString("attribute_name");
			String attribute_value  = rs.getString("attribute_value");
			System.out.println(attribute_name+"="+attribute_value);
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
