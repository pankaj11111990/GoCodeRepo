package com.amazon.loading;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
public class LoadCSV extends Thread{

	static Connection con =null;
	long time;
	File file;
	LoadCSV(File fileName,long timestamp)
	{
		file=fileName;
		
		time=timestamp;
		start();
	}
	public void run()
	{
//		while(true)
//		{
			load();
			
//		}
	}
	public void load()
	{
		
		String ctlFileName = file.getAbsolutePath();
		ctlFileName = ctlFileName.replace(".csv", ".ctl");
			   try {
				   String line=null;
				   File newFile = new File(ctlFileName);
				   BufferedReader br = new BufferedReader( new FileReader("E:\\Files\\Input_record\\Loader_control_file.ctl"));
				   PrintWriter writer = new PrintWriter(ctlFileName);
			       while((line=br.readLine())!=null)
			       {
			    	   System.out.println(line);
			    	   if(line.contains("timeStamp"))
			    		   line = line.replace("timeStamp", ""+time);
			    	   writer.println(line);
			    	   
			       }
			       writer.close();
				   loadFileInDb(file.getAbsolutePath(),ctlFileName);
				   callProc();
				   newFile.delete();
				   br.close();
				   file.delete();
				   NotofySubscriber.readConf("E:\\Files\\Input_record\\",time);
			   }
			   catch (Exception e)
			   {
				   e.printStackTrace();
			   }
		
	}

	public void loadFileInDb(String csv,String ctl)
	{
		try {
		    StringBuilder cmd = new StringBuilder();
		    Runtime rt = Runtime.getRuntime();
		    String osName = System.getProperty("os.name");
		    System.out.println("Operating System: " + osName);
		    if (osName.contains("Windows"))
		    {
		    	cmd.append("cmd.exe");
		    	cmd.append(" /C");
//		    	cmd.append(" set ORACLE_HOME = E:\\app\\Praveen\\product\\11.2.0\\dbhome_1");
//		    	cmd.append(" set PATH=E:\\app\\Praveen\\product\\11.2.0\\dbhome_1\\bin");
		    	cmd.append(" sqlldr scott@orcl/tiger control='"+ctl+"'"+" data='"+csv+"'");
		    	System.out.println(cmd.toString());
		    	Process proc = rt.exec(cmd.toString());
		 
		    // any error?
		    	int exitVal;
		    	exitVal = proc.waitFor();
		    	System.out.println("ExitValue: " + exitVal);
		     
		    	if (exitVal != 0) 
		    	{
		    		System.out.println("The command line job did not execute successfully");
		    	}
		    	else
		    	{
		    		System.out.println("The command line job executed successfully."+exitVal); 
		    	}
		     
		    } 
		} 
		catch (InterruptedException e)
		{
		    
		    e.printStackTrace();
		} 
		catch (IOException e) 
		{
		    
		    e.printStackTrace();
		         
		}
		catch(Exception e){
			
		}
	    
	}
	public synchronized static void callProc()
	{
		
		try {
		con= getConnection();
        System.out.println("Connected to database");
        Statement stmt = null;
           System.out.println("Creating statement...");
           stmt = con.createStatement();
           String sql = "delete from all_csv_records icr where insert_at != (select max(insert_at) from all_csv_records where icr.item= item and icr.attribute_name = attribute_name)";
           stmt.executeUpdate(sql);
    	}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	
	}
	public static Connection getConnection()
	{
		if(con!=null)
		{
			return con;
		}
		else{
		try{
        Class.forName("oracle.jdbc.driver.OracleDriver");
        String url = "jdbc:oracle:thin:@localhost:1521:orcl";
        con = DriverManager.getConnection(url, "scott", "tiger");
        System.out.println("Connected to database");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		}
		return con;

	}
}
