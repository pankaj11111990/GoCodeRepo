package com.amazon.loading;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) 
	{
		String str="GET 100";
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Scanner getCommand = new Scanner(System.in);
		new MainLoadCSV();
		while(true)
		{
			try
			{
				while((str=getCommand.nextLine())!=null)
				{
					if(str.startsWith("GET"))
						new GetQuery(str.substring(4, str.length()));
				}
			}
			catch(Exception e)
			{
				
			}
		}

	}

}
