package com.amazon.loading;

import java.io.File;

public class MainLoadCSV extends Thread 
{
	
	MainLoadCSV()
	{
		start();
	}
	public void run()
	{
		while(true)
		{
			createThread();
		}
	}
	
	public void createThread()
	{
		File folder = new File("E:\\Files\\Input_record");
		try {
		   for(File f:folder.listFiles())
		   {
			   if(!f.isFile())
			   continue;
			   else if(!f.getName().endsWith(".csv"))
				continue;
			   else
			   {
				   long time = f.lastModified();
				   File newFile = new File(f.getAbsolutePath()+f.lastModified());
				   f.renameTo(newFile);
				   new LoadCSV(newFile,time);
			   }

		   }
		}
		catch (Exception e) 
		{
		    e.printStackTrace();      
		}
	}

}
